﻿using InsuranceApplication.Helper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;
using System.Linq;
using System.Threading.Tasks;
using InsuranceApplication.Models;
using System.Text;

namespace InsuranceApplication.Controllers
{
    public class InsuranceController : Controller
    {
        InsuranceAPI _api = new InsuranceAPI();
        private List<PartnerData> jsonCovert;

        public async Task<IActionResult> Index()
        {
            List<PartnerData> Insurance = new List<PartnerData>();
            var rp = new ResponsePartners();
            try
            {
               
                HttpClient client = _api.Initial();
                HttpResponseMessage res = await client.GetAsync("api/Home");
                if (res.IsSuccessStatusCode)
                {
                    var results = res.Content.ReadAsStringAsync().Result;
                    // Insurance = JsonConvert.DeserializeObject<List<PartnerData>>(results);
                     rp = JsonConvert.DeserializeObject<ResponsePartners>(results);
                    return View(rp.PartnersDetails);
                }
            }
            catch(Exception ex)
            {

            }
            return View(rp.PartnersDetails);   
        }

        [Route("Partners")]
        public async Task<IActionResult> Partners()
        {
           
            
            return View();
        }

        [HttpPost("SaveReg")]        
        public async Task<IActionResult> SaveReg([FromBody] PartnerData objpartner)
        {        
            try
            {
                if(objpartner == null)
                {
                    return BadRequest("Pre condition failed");
                }
                var rp = new ResponsePartners();
                HttpClient client = _api.Initial();
                HttpResponseMessage res = await client.PostAsync("api/SavePartner", new StringContent(JsonConvert.SerializeObject(objpartner), Encoding.UTF8, "application/json"));
                if (res.IsSuccessStatusCode)
                {
                    var results = res.Content.ReadAsStringAsync().Result;
                    // Insurance = JsonConvert.DeserializeObject<List<PartnerData>>(results);
                    rp = JsonConvert.DeserializeObject<ResponsePartners>(results);
                    return Ok(rp.message);
                }
                return BadRequest("Some thing went wromg, data not saved");
            }
            catch (Exception ex)
            {
                return BadRequest("Bad Request");
            }            
        }

        [Route("GetPartnerAll")]

        [HttpGet("GetPartnerAll")]
        public async Task<IActionResult> GetPartnerAll()
        {           
            
            return View("~/Views/Insurance/GetPartner.cshtml");

        }

        [HttpGet("GetPartner")]
        
        public async Task<IActionResult> GetPartner([FromQuery] string fromDate, [FromQuery] string toDate, [FromQuery] string listType)
        {
            var rp = new ResponsePartners();
            try
            {              
                HttpClient client = _api.Initial();
                HttpResponseMessage res = await client.GetAsync("api/GetPartners?Fromdate=" +fromDate + "&Todate="+toDate+ "&retunType="+listType);
                if (res.IsSuccessStatusCode)
                {
                    var results = res.Content.ReadAsStringAsync().Result;                   
                    rp = JsonConvert.DeserializeObject<ResponsePartners>(results);               
                }               
            }
            catch (Exception ex)
            {
               
            }
            return PartialView("~/Views/Shared/_GetPartner.cshtml", rp.PartnersDetails);
        }


    }
}
