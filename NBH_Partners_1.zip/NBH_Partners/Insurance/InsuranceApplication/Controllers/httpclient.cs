﻿namespace InsuranceApplication.Controllers
{
    internal class httpclient
    {
    }
}