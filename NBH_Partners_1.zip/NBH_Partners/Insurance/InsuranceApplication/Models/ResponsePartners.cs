﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceApplication.Models
{
    public class ResponsePartners
    {
        public string message { get; set; }
        public string current_time { get; set; }
        public string status { get; set; }
        public List<PartnerData> PartnersDetails { get; set; }
    }
}
