﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceApplication.Models
{
    public class ReportData
    {
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string listType { get; set; }


    }
}
