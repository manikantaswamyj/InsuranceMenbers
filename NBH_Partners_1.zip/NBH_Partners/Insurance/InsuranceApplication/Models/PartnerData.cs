﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceApplication.Models
{
    public class PartnerData 
    {
        [Key]
        public long ParterId { get; set; }
        public string PartnerName { get; set; }
        public int InsuredNumbers { get; set; }
        public int Seniors { get; set; }
        public decimal AnnualRevenue { get; set; }
        public int EstablishmentYear { get; set; }
        public DateTime CrearedTime { get; set; }
    }
}
