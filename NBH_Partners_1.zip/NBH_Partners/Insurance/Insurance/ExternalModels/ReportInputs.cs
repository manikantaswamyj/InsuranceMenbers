﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Insurance.ExternalModels
{
    public class ReportInputs
    {
        public string Fromdate { get; set; }
        public string Todate { get; set; }
        public string retunType { get; set; }
    }
}
