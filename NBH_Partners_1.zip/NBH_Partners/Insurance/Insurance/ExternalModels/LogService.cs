﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Insurance.ExternalModels
{
    public class LogService
    {
        public void TraceService(object exception)
        {
            string str = @"D:\Applications\NBH_Partner\Log\Log.txt";
            string path1 = str.Substring(0, str.LastIndexOf("\\"));
            string path2 = str.Substring(0, str.LastIndexOf(".txt")) + "-" + DateTime.Today.ToString("dd-MM-yyyy") + ".txt";
            try
            {
                if (!Directory.Exists(path1))
                    Directory.CreateDirectory(path1);
                if (path2.Length >= Convert.ToInt32(4000000))
                {
                    path2 = str.Substring(0, str.LastIndexOf(".txt")) + "-" + "2" + ".txt";
                }
                StreamWriter streamWriter = File.AppendText(path2);
                streamWriter.WriteLine(System.DateTime.Now + " :" + exception.ToString());
                streamWriter.Flush();
                streamWriter.Close();

            }
            catch (UnauthorizedAccessException ex)
            {

            }
        }
    }
}
