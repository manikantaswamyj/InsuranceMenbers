﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Insurance.ExternalModels
{
    public class Partner
    {

        public string message { get; set; }
        public string current_time { get; set; }
        public string status { get; set; }
        public object PartnersDetails { get; set; }
    }
}
