﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Insurance.Models.NBH_Insurance
{
    public partial class TPartnersDetails
    {
        public long ParterId { get; set; }
        public string PartnerName { get; set; }
        public int InsuredNumbers { get; set; }
        public int Seniors { get; set; }
        public decimal AnnualRevenue { get; set; }
        public int EstablishmentYear { get; set; }
        public DateTime CrearedTime { get; set; }
    }
}
