﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Insurance.Models.NBH_Insurance
{
    public partial class NBH_InsuranceContext : DbContext
    {
        public NBH_InsuranceContext()
        {
        }

        public NBH_InsuranceContext(DbContextOptions<NBH_InsuranceContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TPartnersDetails> TPartnersDetails { get; set; }

       

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=LAPI-MJ089408\\SQLEXPRESS;Initial Catalog=NBH_Insurance;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TPartnersDetails>(entity =>
            {
                entity.HasKey(e => e.ParterId)
                    .HasName("PK__t_Partne__584F7CA4254C9576");

                entity.ToTable("t_Partners_details");

                entity.Property(e => e.AnnualRevenue).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.CrearedTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PartnerName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
