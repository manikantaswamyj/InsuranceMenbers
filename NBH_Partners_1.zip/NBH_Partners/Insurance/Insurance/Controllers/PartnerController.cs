﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Insurance.Models.NBH_Insurance;
using Insurance.ExternalModels;
using Microsoft.EntityFrameworkCore;

namespace Insurance.Controllers
{
    [Route("api/[controller]")]    
    [ApiController]
   
    public class PartnerController : Controller
    {
        NBH_InsuranceContext nbhDb;
        LogService log;
        public PartnerController()
        {
            nbhDb = new NBH_InsuranceContext();
            log=new LogService();
        }

        string currentTime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

        [HttpGet]

        public dynamic Get()
        {
            Partner _objPartner = new Partner();
            _objPartner.message = "Pre codition failed : parterId";
            _objPartner.status = "0";
            _objPartner.current_time = currentTime;
            log.TraceService("Pre codition failed");
            return StatusCode(StatusCodes.Status412PreconditionFailed, _objPartner);
        }

         [HttpGet("{parterId}")]
        
        public dynamic isGet(long parterId)
        {            
            Partner _objPartner = new Partner();           
            try
            {
                 if (parterId != null && parterId <=0 )
                {
                    _objPartner.message = "Pre codition failed : parterId" + parterId;
                    _objPartner.status = "0";
                    _objPartner.current_time = currentTime;
                    log.TraceService("Pre codition failed");
                    return StatusCode(StatusCodes.Status412PreconditionFailed, _objPartner);
                }
                var partner = (from p in nbhDb.TPartnersDetails
                             where p.ParterId == parterId
                               select new { p.ParterId, p.PartnerName }).ToList();
                if (partner.Count <= 0)
                {
                    _objPartner.message = "false";
                    _objPartner.status = "0";
                    _objPartner.current_time = currentTime;
                    log.TraceService("Request recieved for :" + Convert.ToString(parterId) + " Failure");
                    return StatusCode(StatusCodes.Status204NoContent, _objPartner);                    
                }
                _objPartner.message = "true";
                _objPartner.status = "1";
                _objPartner.current_time = currentTime;
                log.TraceService("Request recieved for :" + parterId.ToString());
                return StatusCode(StatusCodes.Status201Created, _objPartner);
            }
            catch (Exception ex)
            {

                _objPartner.message = "Exception";
                _objPartner.status = "-1";
                _objPartner.current_time = currentTime;
                log.TraceService("Login Request: " + ex.Message.ToString());
                return StatusCode(StatusCodes.Status500InternalServerError, _objPartner);

            }
        }

        

      

    }
}
