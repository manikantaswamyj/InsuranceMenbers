﻿using Insurance.ExternalModels;
using Insurance.Models.NBH_Insurance;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Insurance.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SavePartnerController : Controller
    {
        NBH_InsuranceContext nbhDb;
        LogService log;
        public SavePartnerController()
        {
            nbhDb = new NBH_InsuranceContext();
            log = new LogService();
        }

        string currentTime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        [HttpPost]
        public dynamic Post([FromBody] TPartnersDetails user)
        {
            Partner _objPartner = new Partner();
            try
            {
                if(user == null)
                {
                    _objPartner.message = "Pre codition failed" + user;
                    _objPartner.status = "0";
                    _objPartner.current_time = currentTime;
                    log.TraceService("Pre codition failed");
                    return StatusCode(StatusCodes.Status412PreconditionFailed, _objPartner);
                }
                else if(string.IsNullOrEmpty(user.PartnerName) ||  Convert.ToInt32(user.InsuredNumbers)<=0
                     || Convert.ToInt32(user.Seniors) <= 0 || Convert.ToDecimal(user.AnnualRevenue) <= 0 || Convert.ToInt32(user.EstablishmentYear) <= 0)
                {
                    _objPartner.message = "Pre codition failed"+ user;
                    _objPartner.status = "0";
                    _objPartner.current_time = currentTime;
                    log.TraceService("Pre codition failed");
                    return StatusCode(StatusCodes.Status412PreconditionFailed, _objPartner);
                }
                

                nbhDb.Add<TPartnersDetails>(user);
                nbhDb.SaveChanges();                
                if (user.ParterId==0)
                {
                    _objPartner.message = "Some thing Went Wrong";
                    _objPartner.status = "0";
                    _objPartner.current_time = currentTime;
                    log.TraceService("Login Request: Failure");
                    return StatusCode(StatusCodes.Status400BadRequest, _objPartner);                   
                }
                _objPartner.message = Convert.ToString(user.ParterId);
                _objPartner.status = "1";
                _objPartner.current_time = currentTime;
                return StatusCode(StatusCodes.Status201Created, _objPartner);
            }

            catch (Exception ex)
            {
                _objPartner.message = "Exception";
                _objPartner.status = "-1";
                _objPartner.current_time = currentTime;
                log.TraceService("Login Request: " + ex.Message.ToString());
                return StatusCode(StatusCodes.Status500InternalServerError, _objPartner);

            }

        }
    }
}
