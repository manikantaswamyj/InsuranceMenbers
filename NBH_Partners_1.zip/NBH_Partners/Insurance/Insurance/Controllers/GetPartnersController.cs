﻿using Insurance.ExternalModels;
using Insurance.Models.NBH_Insurance;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Insurance.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetPartnersController : Controller
    {
        NBH_InsuranceContext nbhDb;
        LogService log;
        public GetPartnersController()
        {
            nbhDb = new NBH_InsuranceContext();
            log = new LogService();
        }
        // [HttpGet("{Fromdate}/{Todate}/{retunType}")]
        [HttpGet]
        public dynamic Get([FromQuery]  string fromDate, [FromQuery]  string toDate, [FromQuery] string retunType)
        {
            Partner _objPartner = new Partner();
            try
            {
                log.TraceService("Application Request: " + fromDate + ", " + toDate + ", " + retunType);

                if (string.IsNullOrEmpty(fromDate) )
                {
                    _objPartner.message = "Pre codition failed : FromDate" + fromDate;
                    _objPartner.status = "0";
                    _objPartner.current_time = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    log.TraceService("Pre codition failed");
                    return StatusCode(StatusCodes.Status412PreconditionFailed, _objPartner);
                }
                else if (string.IsNullOrEmpty(toDate))
                {
                    _objPartner.message = "Pre codition failed : Todate" + toDate;
                    _objPartner.status = "0";
                    _objPartner.current_time = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    log.TraceService("Pre codition failed");
                    return StatusCode(StatusCodes.Status412PreconditionFailed, _objPartner);
                }
                else if (string.IsNullOrEmpty(retunType))
                {
                    _objPartner.message = "Pre codition failed : retunType" + retunType;
                    _objPartner.status = "0";
                    _objPartner.current_time = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    log.TraceService("Pre codition failed");
                    return StatusCode(StatusCodes.Status412PreconditionFailed, _objPartner);
                }
                
                var partnersList = nbhDb.TPartnersDetails.FromSqlRaw("sp_get_Applications {0},{1},{2}", fromDate, toDate, retunType).ToList();

                if (partnersList.Count <= 0)
                {
                    _objPartner.message = "No Data found";
                    _objPartner.status = "0";
                    _objPartner.current_time = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    log.TraceService("No Records found");
                    return StatusCode(StatusCodes.Status400BadRequest, _objPartner);                   
                }
                _objPartner.message = "Success";
                _objPartner.status = "1";
                _objPartner.current_time = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                _objPartner.PartnersDetails = partnersList;
                log.TraceService("Request: Success");
                return StatusCode(StatusCodes.Status201Created, _objPartner);
            }

            catch (Exception ex)
            {
                _objPartner.message = "Exception";
                _objPartner.status = "-1";
                _objPartner.current_time = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                log.TraceService("Login Request: " + ex.Message.ToString());
                return StatusCode(StatusCodes.Status500InternalServerError, _objPartner);

            }

        }
    }
}
